"use client"

import type React from "react"

import { useState, useRef, useCallback, useEffect } from "react"
import { Upload, Video, Play, Pause, Settings, RotateCcw, Info, Send, MessageCircle, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ScrollArea } from "@/components/ui/scroll-area"
import { GoogleGenerativeAI } from "@google/generative-ai"

interface ChatMessage {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

export default function SignLanguageTranslator() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [isRecording, setIsRecording] = useState(false)
  const [recordedVideo, setRecordedVideo] = useState<string | null>(null)
  const [translation, setTranslation] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [apiKey, setApiKey] = useState("")
  const [isConfigOpen, setIsConfigOpen] = useState(false)
  const [showWelcomeAlert, setShowWelcomeAlert] = useState(true)
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)
  const [showInstallPrompt, setShowInstallPrompt] = useState(false)

  // Chat states
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([])
  const [chatInput, setChatInput] = useState("")
  const [isChatLoading, setIsChatLoading] = useState(false)

  useEffect(() => {
    // Cargar API key guardada del localStorage
    const savedApiKey = localStorage.getItem("gemini-api-key")
    if (savedApiKey) {
      setApiKey(savedApiKey)
      setShowWelcomeAlert(false)
    }

    // PWA Install prompt
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault()
      setDeferredPrompt(e)
      setShowInstallPrompt(true)
    }

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt)

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt)
    }
  }, [])

  const videoRef = useRef<HTMLVideoElement>(null)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const chunksRef = useRef<Blob[]>([])
  const chatScrollRef = useRef<HTMLDivElement>(null)

  const installPWA = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt()
      const { outcome } = await deferredPrompt.userChoice
      if (outcome === "accepted") {
        setShowInstallPrompt(false)
      }
      setDeferredPrompt(null)
    }
  }

  // Función para convertir ArrayBuffer a base64 de manera eficiente
  const arrayBufferToBase64 = (buffer: ArrayBuffer): Promise<string> => {
    return new Promise((resolve, reject) => {
      try {
        const blob = new Blob([buffer])
        const reader = new FileReader()
        reader.onload = () => {
          const dataUrl = reader.result as string
          const base64 = dataUrl.split(",")[1]
          resolve(base64)
        }
        reader.onerror = reject
        reader.readAsDataURL(blob)
      } catch (error) {
        reject(error)
      }
    })
  }

  const showAlert = (message: string, type: "error" | "success" | "info" = "error") => {
    alert(message)
  }

  const scrollToBottom = () => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight
    }
  }

  useEffect(() => {
    scrollToBottom()
  }, [chatMessages])

  const sendChatMessage = async () => {
    if (!chatInput.trim()) return

    if (!apiKey.trim()) {
      showAlert("Por favor, configura tu API Key de Gemini primero para usar el chatbot.")
      setIsConfigOpen(true)
      return
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: chatInput.trim(),
      timestamp: new Date(),
    }

    setChatMessages((prev) => [...prev, userMessage])
    setChatInput("")
    setIsChatLoading(true)

    try {
      const genAI = new GoogleGenerativeAI(apiKey.trim())
      const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" })

      const prompt = `Eres un asistente especializado en lenguaje de señas argentino (LSA) y temas relacionados. 
      Responde de manera útil y amigable en español. Si te preguntan sobre lenguaje de señas, enfócate en el LSA.
      
      Pregunta del usuario: ${userMessage.content}`

      const result = await model.generateContent(prompt)
      const response = await result.response
      const text = response.text()

      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: text || "Lo siento, no pude generar una respuesta.",
        timestamp: new Date(),
      }

      setChatMessages((prev) => [...prev, assistantMessage])
    } catch (error: any) {
      console.error("Error en chat:", error)

      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "Lo siento, hubo un error al procesar tu mensaje. Verifica tu API Key o intenta nuevamente.",
        timestamp: new Date(),
      }

      setChatMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsChatLoading(false)
    }
  }

  const clearChat = () => {
    setChatMessages([])
  }

  const startRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480 },
        audio: false,
      })

      streamRef.current = stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream
      }

      const mediaRecorder = new MediaRecorder(stream)
      mediaRecorderRef.current = mediaRecorder
      chunksRef.current = []

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data)
        }
      }

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: "video/webm" })
        const videoUrl = URL.createObjectURL(blob)
        setRecordedVideo(videoUrl)

        if (videoRef.current) {
          videoRef.current.srcObject = null
          videoRef.current.src = videoUrl
        }
      }

      mediaRecorder.start()
      setIsRecording(true)
    } catch (error) {
      console.error("Error accessing camera:", error)
      showAlert("Error al acceder a la cámara. Por favor, permite el acceso a la cámara en tu navegador.")
    }
  }, [])

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
      setIsRecording(false)

      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
      }
    }
  }, [isRecording])

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      if (file.type.startsWith("video/")) {
        setSelectedFile(file)
        setRecordedVideo(null)
        setTranslation("")

        const videoUrl = URL.createObjectURL(file)
        if (videoRef.current) {
          videoRef.current.src = videoUrl
          videoRef.current.srcObject = null
          videoRef.current.load()
        }
      } else {
        showAlert("Por favor, selecciona un archivo de video válido (MP4, AVI, MOV, etc.).")
      }
    }
    // Reset the input value to allow selecting the same file again
    event.target.value = ""
  }

  const analyzeVideo = async () => {
    if (!selectedFile && !recordedVideo) {
      showAlert("Por favor, sube un video o graba uno nuevo antes de traducir.")
      return
    }

    setIsAnalyzing(true)
    setTranslation("")

    try {
      // Validar API Key antes de usarla
      if (!apiKey.trim()) {
        showAlert("Por favor, configura tu API Key de Gemini primero. Ve a Configuración para ingresarla.")
        setIsConfigOpen(true)
        return
      }

      // Limpiar la API Key de espacios extra
      const cleanApiKey = apiKey.trim()

      if (cleanApiKey.length < 20) {
        showAlert("La API Key parece ser demasiado corta. Verifica que la hayas copiado completamente.")
        setIsConfigOpen(true)
        return
      }

      const genAI = new GoogleGenerativeAI(cleanApiKey)
      const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" })

      let videoData: ArrayBuffer
      let mimeType: string

      if (selectedFile) {
        // Verificar tamaño del archivo (máximo 1GB)
        if (selectedFile.size > 1024 * 1024 * 1024) {
          throw new Error("El archivo es demasiado grande. El tamaño máximo permitido es 1GB.")
        }
        videoData = await selectedFile.arrayBuffer()
        mimeType = selectedFile.type
      } else if (recordedVideo) {
        const response = await fetch(recordedVideo)
        videoData = await response.arrayBuffer()
        mimeType = "video/webm"
      } else {
        throw new Error("No hay video disponible para analizar")
      }

      // Convertir a base64 de manera segura
      const base64String = await arrayBufferToBase64(videoData)

      const videoPart = {
        inlineData: {
          data: base64String,
          mimeType: mimeType,
        },
      }

      const prompt = `Analiza este video de Lenguaje de Señas Argentino (LSA) y traduce los gestos a palabras en español. 
      El LSA tiene características específicas de Argentina y puede diferir de otros lenguajes de señas.
      
      Describe detalladamente qué gestos o señas observas y proporciona la traducción más precisa posible. 
      Si no puedes identificar claramente las señas del LSA, explica qué observas en el video y menciona que podría ser necesario un video más claro o con mejor iluminación.
      
      Responde únicamente en español y enfócate en el contexto del Lenguaje de Señas Argentino.`

      console.log("Enviando video a Gemini...", { mimeType, size: videoData.byteLength })

      const result = await model.generateContent([prompt, videoPart])
      const response = await result.response
      const text = response.text()

      if (!text || text.trim() === "") {
        throw new Error("Gemini no pudo generar una respuesta para este video")
      }

      setTranslation(text)
      showAlert("¡Traducción completada exitosamente!", "success")
    } catch (error: any) {
      console.error("Error completo:", error)
      console.error("Error message:", error.message)
      console.error("Error status:", error.status)

      let errorMessage = "Error desconocido al analizar el video."

      // Verificar diferentes tipos de errores de API Key
      if (error.status === 400 && (error.message?.includes("API key") || error.message?.includes("invalid"))) {
        errorMessage = `Tu API Key no es válida o no tiene permisos para usar Gemini. 
    
Verifica que:
1. La API Key esté copiada completamente
2. Hayas habilitado la API de Gemini en Google AI Studio
3. Tu cuenta tenga acceso a Gemini

API Key actual: ${apiKey.substring(0, 10)}...`
      } else if (error.status === 403) {
        errorMessage = `Acceso denegado. Tu API Key no tiene permisos para usar Gemini.
    
Ve a Google AI Studio y verifica que:
1. La API Key esté activa
2. Tengas permisos para usar Gemini
3. No hayas excedido los límites de uso`
      } else if (error.status === 429) {
        errorMessage = "Has excedido el límite de uso de tu API Key. Espera un momento antes de intentar nuevamente."
      } else if (error.message?.includes("fetch")) {
        errorMessage = "Error de conexión a internet. Verifica tu conexión y vuelve a intentar."
      } else if (error.message?.includes("demasiado grande")) {
        errorMessage = error.message
      } else if (error.message?.includes("blocked") || error.message?.includes("safety")) {
        errorMessage = "El contenido del video fue bloqueado por las políticas de seguridad de Gemini."
      } else if (error.message) {
        errorMessage = `Error específico: ${error.message}
    
Si el problema persiste, verifica tu API Key en Configuración.`
      }

      showAlert(errorMessage)
      setTranslation("")
    } finally {
      setIsAnalyzing(false)
    }
  }

  const resetAll = () => {
    setSelectedFile(null)
    setRecordedVideo(null)
    setTranslation("")
    if (videoRef.current) {
      videoRef.current.src = ""
      videoRef.current.srcObject = null
    }
  }

  const saveConfiguration = () => {
    const trimmedKey = apiKey.trim()

    if (!trimmedKey) {
      showAlert("Por favor, ingresa una API Key antes de guardar.")
      return
    }

    if (trimmedKey.length < 20) {
      showAlert("La API Key parece ser demasiado corta. Verifica que la hayas copiado completamente.")
      return
    }

    if (!trimmedKey.startsWith("AIza")) {
      showAlert("La API Key de Google debe comenzar con 'AIza'. Verifica que hayas copiado la clave correcta.")
      return
    }

    localStorage.setItem("gemini-api-key", trimmedKey)
    setApiKey(trimmedKey)
    setIsConfigOpen(false)
    setShowWelcomeAlert(false)
    showAlert("¡Configuración guardada exitosamente! Ya puedes usar la aplicación.", "success")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-4xl mx-auto">
        {/* PWA Install Prompt */}
        {showInstallPrompt && (
          <Alert className="mb-6 border-green-200 bg-green-50">
            <Download className="h-4 w-4" />
            <AlertDescription>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold">¡Instala la aplicación en tu PC!</p>
                  <p className="text-sm">Úsala sin conexión y accede más rápido.</p>
                </div>
                <div className="flex gap-2">
                  <Button onClick={installPWA} size="sm">
                    Instalar
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setShowInstallPrompt(false)}
                    size="sm"
                    className="bg-transparent"
                  >
                    Ahora no
                  </Button>
                </div>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Welcome Alert */}
        {showWelcomeAlert && (
          <Alert className="mb-6 border-blue-200 bg-blue-50">
            <Info className="h-4 w-4" />
            <AlertDescription>
              <div className="space-y-2">
                <p className="font-semibold">¡Bienvenido al Traductor de Lenguaje de Señas Argentino!</p>
                <p>Para usar esta aplicación necesitas una API Key gratuita de Google Gemini.</p>
                <div className="text-sm space-y-1">
                  <p className="font-medium">Pasos para obtener tu API Key:</p>
                  <ol className="list-decimal list-inside space-y-1 ml-2">
                    <li>
                      Ve a{" "}
                      <a
                        href="https://aistudio.google.com/app/apikey"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline"
                      >
                        Google AI Studio
                      </a>
                    </li>
                    <li>Inicia sesión con tu cuenta de Google</li>
                    <li>Haz clic en "Create API Key"</li>
                    <li>Copia la API Key generada</li>
                    <li>Pégala en Configuración de esta aplicación</li>
                  </ol>
                </div>
                <div className="flex gap-2 mt-3">
                  <Button onClick={() => setIsConfigOpen(true)} size="sm">
                    Configurar API Key
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setShowWelcomeAlert(false)}
                    size="sm"
                    className="bg-transparent"
                  >
                    Cerrar
                  </Button>
                </div>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center">
              <span className="text-2xl">🦜</span>
            </div>
            <h1 className="text-4xl text-green-600 font-black">Traductor de lenguaje de señas a palabras</h1>
          </div>
          <p className="text-slate-600">
            Sube un video o graba en tiempo real para traducir LSA (Lenguaje de Señas Argentino)
          </p>
        </div>

        {/* Configuration Button */}
        <div className="flex justify-end mb-6">
          <div className="flex items-center gap-2">
            {apiKey && (
              <div className="flex items-center gap-1 text-sm text-green-600">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                API Key configurada
              </div>
            )}
            <Dialog open={isConfigOpen} onOpenChange={setIsConfigOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="gap-2 bg-transparent">
                  <Settings className="w-4 h-4" />
                  Configuración
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Configuración de API Key</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="apikey">API Key de Google Gemini</Label>
                    <Input
                      id="apikey"
                      type="password"
                      placeholder="Pega tu API Key aquí"
                      value={apiKey}
                      onChange={(e) => setApiKey(e.target.value)}
                      className="mt-1"
                    />
                    <div className="mt-2 p-3 bg-blue-50 rounded-lg text-sm">
                      <p className="font-medium text-blue-800 mb-1">Cómo obtener tu API Key:</p>
                      <ol className="list-decimal list-inside space-y-1 text-blue-700">
                        <li>
                          Ve a{" "}
                          <a
                            href="https://aistudio.google.com/app/apikey"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="underline"
                          >
                            Google AI Studio
                          </a>
                        </li>
                        <li>Inicia sesión con Google</li>
                        <li>Haz clic en "Create API Key"</li>
                        <li>Copia y pega la clave aquí</li>
                      </ol>
                    </div>
                    <p className="text-xs text-slate-400 mt-2">Tu API Key se guarda localmente en tu navegador</p>
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={saveConfiguration} className="flex-1">
                      Guardar
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setApiKey("")
                        localStorage.removeItem("gemini-api-key")
                        showAlert("API Key eliminada correctamente.", "info")
                      }}
                      className="bg-transparent"
                    >
                      Limpiar
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Video Input Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Video className="w-5 h-5" />
                Video de Lenguaje de Señas Argentino
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Video Display */}
              <div className="aspect-video bg-slate-900 rounded-lg overflow-hidden">
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover"
                  controls={!isRecording}
                  autoPlay={isRecording}
                  muted
                />
              </div>

              {/* Controls */}
              <div className="flex flex-wrap gap-2">
                <div className="flex-1">
                  <Button
                    onClick={() => document.getElementById("video-upload")?.click()}
                    variant="outline"
                    className="w-full gap-2 bg-transparent"
                  >
                    <Upload className="w-4 h-4" />
                    Subir Video
                  </Button>
                  <input
                    type="file"
                    accept="video/*"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="video-upload"
                  />
                </div>

                <Button
                  onClick={isRecording ? stopRecording : startRecording}
                  variant={isRecording ? "destructive" : "default"}
                  className="gap-2"
                >
                  {isRecording ? (
                    <>
                      <Pause className="w-4 h-4" />
                      Detener
                    </>
                  ) : (
                    <>
                      <Video className="w-4 h-4" />
                      Grabar
                    </>
                  )}
                </Button>

                <Button onClick={resetAll} variant="outline" className="gap-2 bg-transparent">
                  <RotateCcw className="w-4 h-4" />
                  Limpiar
                </Button>
              </div>

              {/* Analyze Button */}
              <Button
                onClick={analyzeVideo}
                disabled={isAnalyzing || (!selectedFile && !recordedVideo)}
                className="w-full gap-2 bg-green-600 hover:bg-green-700"
              >
                {isAnalyzing ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Analizando video...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4" />
                    Traducir Señas
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Translation Results */}
          <Card>
            <CardHeader>
              <CardTitle>Traducción</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={translation}
                readOnly
                placeholder="La traducción del LSA aparecerá aquí después de analizar el video..."
                className="min-h-[300px] resize-none"
              />
              {translation && (
                <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-sm text-green-700">✓ Traducción completada exitosamente</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Chatbot Section */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5" />
              Asistente de LSA - Chatbot
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Chat Messages */}
            <ScrollArea className="h-80 w-full border rounded-lg p-4" ref={chatScrollRef}>
              {chatMessages.length === 0 ? (
                <div className="text-center text-slate-500 py-8">
                  <MessageCircle className="w-12 h-12 mx-auto mb-4 text-slate-300" />
                  <p>¡Hola! Soy tu asistente especializado en Lenguaje de Señas Argentino.</p>
                  <p className="text-sm mt-2">
                    Puedes preguntarme sobre LSA, señas específicas, o cualquier otra cosa.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {chatMessages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[80%] rounded-lg p-3 ${
                          message.role === "user" ? "bg-green-600 text-white" : "bg-slate-100 text-slate-900"
                        }`}
                      >
                        <p className="text-sm">{message.content}</p>
                        <p className="text-xs opacity-70 mt-1">{message.timestamp.toLocaleTimeString()}</p>
                      </div>
                    </div>
                  ))}
                  {isChatLoading && (
                    <div className="flex justify-start">
                      <div className="bg-slate-100 rounded-lg p-3">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                          <div
                            className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"
                            style={{ animationDelay: "0.1s" }}
                          ></div>
                          <div
                            className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"
                            style={{ animationDelay: "0.2s" }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </ScrollArea>

            {/* Chat Input */}
            <div className="flex gap-2">
              <Input
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Pregúntame sobre LSA o cualquier otra cosa..."
                onKeyPress={(e) => e.key === "Enter" && !e.shiftKey && sendChatMessage()}
                disabled={isChatLoading}
                className="flex-1"
              />
              <Button onClick={sendChatMessage} disabled={isChatLoading || !chatInput.trim()} className="gap-2">
                <Send className="w-4 h-4" />
                Enviar
              </Button>
              <Button
                onClick={clearChat}
                variant="outline"
                className="gap-2 bg-transparent"
                disabled={chatMessages.length === 0}
              >
                <RotateCcw className="w-4 h-4" />
                Limpiar
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Instructions */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Instrucciones de Uso</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4 text-sm text-slate-600">
              <div>
                <h4 className="font-semibold mb-2">Para subir un video:</h4>
                <ol className="list-decimal list-inside space-y-1">
                  <li>Haz clic en "Subir Video"</li>
                  <li>Selecciona un archivo de video (máximo 1GB)</li>
                  <li>Haz clic en "Traducir Señas"</li>
                </ol>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Para grabar en vivo:</h4>
                <ol className="list-decimal list-inside space-y-1">
                  <li>Haz clic en "Grabar"</li>
                  <li>Permite el acceso a la cámara</li>
                  <li>Realiza las señas frente a la cámara</li>
                  <li>Haz clic en "Detener" y luego "Traducir Señas"</li>
                </ol>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Para usar el chatbot:</h4>
                <ol className="list-decimal list-inside space-y-1">
                  <li>Escribe tu pregunta en el chat</li>
                  <li>Presiona Enter o haz clic en "Enviar"</li>
                  <li>El asistente responderá sobre LSA o cualquier tema</li>
                </ol>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Credits */}
      <div className="fixed bottom-4 right-4 text-xs text-slate-400 bg-white/80 px-2 py-1 rounded">
        Created by Borkoski & Fonseca
      </div>
    </div>
  )
}
