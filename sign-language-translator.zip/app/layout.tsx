import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Traductor de lenguaje de señas a palabras",
  description:
    "Aplicación para traducir Lenguaje de Señas Argentino (LSA) a palabras usando inteligencia artificial. Incluye chatbot especializado en LSA.",
  keywords: ["lenguaje de señas", "LSA", "traductor", "Argentina", "inteligencia artificial", "Gemini"],
  authors: [{ name: "Borkoski & Fonseca" }],
  creator: "Borkoski & Fonseca",
  publisher: "Borkoski & Fonseca",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL("https://traductor-lsa.vercel.app"),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "Traductor de lenguaje de señas a palabras",
    description: "Traduce Lenguaje de Señas Argentino (LSA) a palabras con IA. Incluye chatbot especializado.",
    url: "https://traductor-lsa.vercel.app",
    siteName: "Traductor LSA",
    images: [
      {
        url: "/icon-512x512.png",
        width: 512,
        height: 512,
        alt: "Traductor de lenguaje de señas a palabras",
      },
    ],
    locale: "es_AR",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Traductor de lenguaje de señas a palabras",
    description: "Traduce Lenguaje de Señas Argentino (LSA) a palabras con IA",
    images: ["/icon-512x512.png"],
    creator: "@BorkoskiFonseca",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  manifest: "/manifest.json",
  icons: {
    icon: [
      { url: "/icon-16x16.png", sizes: "16x16", type: "image/png" },
      { url: "/icon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/icon-192x192.png", sizes: "192x192", type: "image/png" },
      { url: "/icon-512x512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
    shortcut: "/favicon.ico",
  },
  viewport: {
    width: "device-width",
    initialScale: 1,
    maximumScale: 1,
  },
  themeColor: "#16a34a",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es">
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#16a34a" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="Traductor LSA" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="msapplication-TileColor" content="#16a34a" />
        <meta name="msapplication-tap-highlight" content="no" />
      </head>
      <body className={inter.className}>{children}</body>
    </html>
  )
}
